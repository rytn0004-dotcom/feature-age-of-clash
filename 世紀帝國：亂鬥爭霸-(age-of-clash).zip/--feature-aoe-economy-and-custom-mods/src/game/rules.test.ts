import test from 'node:test';
import assert from 'node:assert/strict';
import {
  canAfford,
  deductCost,
  addResources,
  calculateDamage,
  applyBalanceMultipliers,
  evaluateCondition,
  evaluateAiScript,
  getDistance,
  findClosestResourceNode,
  findClosestEnemy,
} from './rules';
import { AiRule, ResourceNode, EntityCommon, TechDefinition, UnitStats, GameMod } from '../types/game';
import { INITIAL_MODS } from './mods';
import { validateAndNormalizeGameMods, validateGameMods } from './modValidation';

test('economy: canAfford accurately checks resource amounts', () => {
  const current = { food: 100, wood: 50, gold: 20, stone: 0 };
  assert.equal(canAfford(current, { food: 50, wood: 20, gold: 0, stone: 0 }), true);
  assert.equal(canAfford(current, { food: 100, wood: 50, gold: 20, stone: 0 }), true);
  assert.equal(canAfford(current, { food: 120, wood: 50, gold: 20, stone: 0 }), false);
  assert.equal(canAfford(current, { food: 50, wood: 20, gold: 50, stone: 0 }), false);
});

test('economy: deductCost and addResources compute correct balances', () => {
  const current = { food: 100, wood: 50, gold: 30, stone: 10 };
  const cost = { food: 40, wood: 25, gold: 0, stone: 5 };
  const afterDeduct = deductCost(current, cost);
  assert.deepEqual(afterDeduct, { food: 60, wood: 25, gold: 30, stone: 5 });

  const afterAdd = addResources(afterDeduct, { food: 15, gold: 10 });
  assert.deepEqual(afterAdd, { food: 75, wood: 25, gold: 40, stone: 5 });
});

test('combat: calculateDamage respects defense and minimum damage of 1', () => {
  assert.equal(calculateDamage(15, 5), 10);
  assert.equal(calculateDamage(10, 10), 1); // min damage floor
  assert.equal(calculateDamage(5, 20), 1); // floor when defense exceeds attack
  assert.equal(calculateDamage(20, 5, 1.5), 25); // with 1.5x multiplier: (30 - 5)
});

test('mods: applyBalanceMultipliers updates unit stats cleanly', () => {
  const base = {
    maxHp: 100,
    attack: 10,
    defense: 2,
    range: 1.5,
    speed: 4,
    attackRate: 1,
    cost: { food: 50, wood: 0, gold: 20, stone: 0 },
    trainTime: 12,
    gatherSpeed: 2,
    carryCapacity: 15,
  };
  const multipliers = {
    gatherRate: 1.5,
    unitHp: 1.2,
    unitDamage: 2.0,
    buildSpeed: 1.0,
    moveSpeed: 1.25,
  };
  const boosted = applyBalanceMultipliers(base, multipliers);
  assert.equal(boosted.maxHp, 120);
  assert.equal(boosted.attack, 20);
  assert.equal(boosted.speed, 5);
  assert.equal(boosted.gatherSpeed, 3);
});

test('ai-script: evaluateCondition checks operators properly', () => {
  const snapshot = {
    food: 200,
    wood: 80,
    gold: 50,
    stone: 0,
    armyCount: 6,
    workerCount: 5,
    underAttack: 1,
    enemyProximity: 15,
    gameTime: 45,
  };

  assert.equal(evaluateCondition({ field: 'food', operator: '>=', value: 200 }, snapshot), true);
  assert.equal(evaluateCondition({ field: 'food', operator: '<', value: 100 }, snapshot), false);
  assert.equal(evaluateCondition({ field: 'underAttack', operator: '==', value: 1 }, snapshot), true);
  assert.equal(evaluateCondition({ field: 'armyCount', operator: '>', value: 5 }, snapshot), true);
});

test('ai-script: evaluateAiScript triggers highest priority rule that matches', () => {
  const rules: AiRule[] = [
    {
      id: 'rule_eco',
      name: 'Train Villagers if food > 50',
      enabled: true,
      conditions: [{ field: 'food', operator: '>=', value: 50 }],
      action: { type: 'train_unit', targetId: 'villager', priority: 10 },
    },
    {
      id: 'rule_defend',
      name: 'Defend if under attack',
      enabled: true,
      conditions: [{ field: 'underAttack', operator: '==', value: 1 }],
      action: { type: 'retreat_to_base', priority: 90 },
    },
    {
      id: 'rule_attack',
      name: 'All out attack if army > 10',
      enabled: true,
      conditions: [{ field: 'armyCount', operator: '>=', value: 10 }],
      action: { type: 'attack_player', priority: 50 },
    },
  ];

  const underAttackSnapshot = {
    food: 100,
    wood: 100,
    gold: 100,
    stone: 0,
    armyCount: 4,
    workerCount: 5,
    underAttack: 1,
    enemyProximity: 10,
    gameTime: 60,
  };

  const action = evaluateAiScript(rules, underAttackSnapshot);
  assert.ok(action);
  assert.equal(action.type, 'retreat_to_base');
});

test('spatial: getDistance, findClosestResourceNode and findClosestEnemy', () => {
  assert.equal(getDistance(0, 0, 3, 4), 5);

  const nodes: ResourceNode[] = [
    { id: 'wood1', resourceType: 'wood', x: 10, z: 10, amount: 100, maxAmount: 100 },
    { id: 'gold1', resourceType: 'gold', x: 3, z: 4, amount: 200, maxAmount: 200 },
    { id: 'wood2', resourceType: 'wood', x: 2, z: 2, amount: 0, maxAmount: 100 }, // empty
  ];

  const closestAny = findClosestResourceNode(0, 0, nodes);
  assert.equal(closestAny?.id, 'gold1');

  const closestWood = findClosestResourceNode(0, 0, nodes, 'wood');
  assert.equal(closestWood?.id, 'wood1');

  const entities: EntityCommon[] = [
    { id: 'ally1', faction: 'player', x: 1, z: 1, hp: 50, maxHp: 50 },
    { id: 'enemy1', faction: 'enemy', x: 8, z: 6, hp: 40, maxHp: 40 },
    { id: 'enemy2', faction: 'enemy', x: 20, z: 20, hp: 40, maxHp: 40 },
    { id: 'deadEnemy', faction: 'enemy', x: 2, z: 2, hp: 0, maxHp: 40 },
  ];

  const enemy = findClosestEnemy(0, 0, 'player', entities);
  assert.equal(enemy?.id, 'enemy1');
});

test('collision: resolveUnitBuildingCollisions pushes units out of solid building core while leaving auto-channel', async () => {
  const { resolveUnitBuildingCollisions, getBuildingCollisionRadius, getUnitColliderRadius } = await import('./collision');
  const dummyUnit = {
    id: 'u1',
    type: 'unit' as const,
    faction: 'player' as const,
    x: 0.1,
    z: 0.1,
    hp: 100,
    maxHp: 100,
    unitDefId: 'villager',
    unitDef: {
      id: 'villager',
      name: '村民',
      factionPack: 'medieval',
      category: 'worker' as const,
      description: '',
      stats: { maxHp: 50, attack: 3, defense: 0, range: 1, speed: 3.5, attackRate: 1, cost: { food: 50, wood: 0, gold: 0, stone: 0 }, trainTime: 8, gatherSpeed: 3, carryCapacity: 15 },
      visual: { color: '#fff', modelType: 'villager' as const },
    },
    state: 'idle' as const,
    attackCooldown: 0,
    abilityCooldown: 0,
    velocity: { x: 0, z: 0 },
    kills: 0,
  };

  const dummyBuilding = {
    id: 'b1',
    type: 'building' as const,
    faction: 'player' as const,
    x: 0,
    z: 0,
    hp: 2000,
    maxHp: 2000,
    buildingType: 'town_center' as const,
    buildingDef: {
      id: 'town_center' as const,
      name: '城鎮中心',
      description: '',
      maxHp: 2400,
      cost: { food: 0, wood: 400, gold: 0, stone: 100 },
      buildTime: 35,
      trainableUnits: [],
      size: 4.5,
    },
    isConstructed: true,
    buildProgress: 1,
    queue: [],
    queueProgress: 0,
    attackCooldown: 0,
  };

  resolveUnitBuildingCollisions([dummyUnit], [dummyBuilding]);
  const expectedMinDist = getBuildingCollisionRadius(dummyBuilding) + getUnitColliderRadius('worker');
  const distAfter = Math.hypot(dummyUnit.x - dummyBuilding.x, dummyUnit.z - dummyBuilding.z);
  assert.ok(
    distAfter >= expectedMinDist - 0.01,
    `Unit distance ${distAfter} should be pushed out beyond core radius ${expectedMinDist}`
  );
  // Farms should allow workers to walk onto plots cleanly
  const farmBuilding = {
    ...dummyBuilding,
    id: 'farm1',
    buildingType: 'farm' as const,
    buildingDef: { ...dummyBuilding.buildingDef, id: 'farm' as const, size: 2.8 },
  };
  assert.equal(getBuildingCollisionRadius(farmBuilding), 0);
});

test('collision: isPlacementLocationValid allows flush buildings and blocks water/cliffs/overlaps', async () => {
  const { isPlacementLocationValid } = await import('./collision');
  const buildings = [
    {
      id: 'tc',
      type: 'building' as const,
      faction: 'player' as const,
      x: 0,
      z: 0,
      hp: 1000,
      maxHp: 1000,
      buildingType: 'town_center' as const,
      buildingDef: { id: 'town_center' as const, name: 'TC', description: '', maxHp: 2000, cost: { food: 0, wood: 0, gold: 0, stone: 0 }, buildTime: 20, trainableUnits: [], size: 4.5 },
      isConstructed: true,
      buildProgress: 1,
      queue: [],
      queueProgress: 0,
      attackCooldown: 0,
    },
  ];
  const nodes = [
    { id: 'gold1', resourceType: 'gold' as const, x: 20, z: 20, amount: 1000, maxAmount: 1000 },
  ];

  // Directly on top of Town Center should be invalid
  assert.equal(isPlacementLocationValid(1, 1, 3.5, buildings, nodes), false);
  // Placed flush right next to TC (4.5 + 3.5 = 8.0 <= 8.2) MUST be valid because inset cores auto-leave a passage channel
  assert.equal(isPlacementLocationValid(8.2, 0, 3.5, buildings, nodes), true);
  // Overlapping TC footprint (7.5 < 4.5 + 3.5) should be invalid
  assert.equal(isPlacementLocationValid(7.5, 0, 3.5, buildings, nodes), false);
  // Directly on top of Gold Node should be invalid
  assert.equal(isPlacementLocationValid(20.5, 20.5, 3.0, buildings, nodes), false);
  // On water strip without bridge should be invalid; on bridge should be valid
  const waterRects = [{ x1: -10, z1: 31, x2: 10, z2: 31, kind: 'water' as const }];
  const bridges = [{ x: 0, z: 31, halfWidth: 2.5, halfLength: 5, angle: 0 }];
  assert.equal(isPlacementLocationValid(6, 31, 1.5, buildings, nodes, false, waterRects, [], bridges), false);
  // In clear space should be valid
  assert.equal(isPlacementLocationValid(35, -20, 3.5, buildings, nodes), true);
});

test('pathfinding: flush buildings leave a passable corridor and units route over river bridges', async () => {
  const { buildNavGrid, findPath } = await import('./pathfinding');
  const makeBarracks = (id: string, x: number, z: number) => ({
    id,
    type: 'building' as const,
    faction: 'enemy' as const,
    x,
    z,
    hp: 1000,
    maxHp: 1000,
    buildingType: 'barracks' as const,
    buildingDef: {
      id: 'barracks' as const,
      name: 'Barracks',
      description: '',
      maxHp: 1200,
      cost: { food: 0, wood: 150, gold: 0, stone: 0 },
      buildTime: 20,
      trainableUnits: [],
      size: 3.5,
    },
    isConstructed: true,
    buildProgress: 1,
    queue: [],
    queueProgress: 0,
    attackCooldown: 0,
  });

  // Two barracks placed completely flush: centers at x=-3.6 and x=3.6 (dist = 7.2 >= 3.5+3.5)
  const bLeft = makeBarracks('bL', -3.6, 0);
  const bRight = makeBarracks('bR', 3.6, 0);
  const gridFlush = buildNavGrid([bLeft, bRight], []);
  const corridorPath = findPath(0, -10, 0, 10, gridFlush);
  assert.ok(corridorPath.length >= 1, 'Expected valid path through auto-channel between flush buildings');
  // Unit should pass cleanly between them (staying within |x| < 1.5 rather than walking all the way around |x| > 6)
  assert.ok(
    corridorPath.every((wp) => Math.abs(wp.x) < 1.5),
    `Expected direct corridor route through gap, got ${JSON.stringify(corridorPath)}`
  );

  // Single blocking building should detour smoothly around perimeter
  const gridSingle = buildNavGrid([makeBarracks('center', 0, 0)], []);
  const detour = findPath(-10, 0, 10, 0, gridSingle);
  assert.ok(detour.some((wp) => Math.abs(wp.z) >= 2.5), 'Expected detour around blocking building');

  // River obstacle across z=0 (x=-65..65) with bridge at x=15 (width 6, x in [12, 18])
  const riverGrid = buildNavGrid([], [], {
    rects: [{ x1: -65, z1: 0, x2: 65, z2: 0, kind: 'water' }],
    discs: [],
    bridges: [{ x: 15, z: 0, halfWidth: 3.0, halfLength: 5.0, angle: 0 }],
  });
  const bridgePath = findPath(-5, -12, -5, 12, riverGrid);
  assert.ok(
    bridgePath.some((wp) => wp.x >= 11 && wp.x <= 19),
    `Expected unit to route over river bridge at x=[12,18], got ${JSON.stringify(bridgePath)}`
  );
});

test('mapGenerator: produces varied terrain features and abundant diverse resources', async () => {
  const { generateMapLayout } = await import('./mapGenerator');
  const spawns = [
    { id: 'player', x: -30, z: -20 },
    { id: 'ai1', x: 30, z: 20 },
  ];

  const river = generateMapLayout('river_valley', 'standard', spawns);
  assert.ok(river.waterRects.length > 0 && river.bridges.length >= 2, 'River Valley should include river and crossings');

  const highland = generateMapLayout('highland_basin', 'standard', spawns);
  assert.ok(highland.cliffDiscs.length >= 4, 'Highland Basin should include rocky cliff outcrops');

  const lakes = generateMapLayout('twin_lakes', 'abundant', spawns);
  assert.ok(lakes.waterDiscs.length >= 2, 'Twin Lakes should include two lakes');

  const riverAbundant = generateMapLayout('river_valley', 'abundant', spawns);
  assert.ok(riverAbundant.resourceNodes.some((n) => n.subtype === 'berry'), 'Map should spawn berry bushes');
  assert.ok(riverAbundant.resourceNodes.some((n) => n.subtype === 'hunt'), 'Map should spawn deer herds');
  assert.ok(
    riverAbundant.resourceNodes.filter((n) => n.resourceType === 'gold').length >= 6,
    'Map should spawn multiple gold veins'
  );
  assert.ok(
    riverAbundant.resourceNodes.length > river.resourceNodes.length,
    'Abundant richness should spawn more resource nodes than standard'
  );
});

test('controlGroups: supports assigning, appending, and pruning dead units', async () => {
  const { createEmptyControlGroups, updateControlGroup, pruneControlGroups } = await import('./controlGroups');
  let groups = createEmptyControlGroups();
  groups = updateControlGroup(groups, 1, ['u1', 'u2'], false);
  assert.deepEqual(groups[1], ['u1', 'u2']);

  // Append u2 (duplicate) and u3
  groups = updateControlGroup(groups, 1, ['u2', 'u3'], true);
  assert.deepEqual(groups[1], ['u1', 'u2', 'u3']);

  // Overwrite group 1
  groups = updateControlGroup(groups, 1, ['u4'], false);
  assert.deepEqual(groups[1], ['u4']);

  // Prune dead units
  groups = updateControlGroup(groups, 2, ['u1', 'u4'], false);
  groups = pruneControlGroups(groups, new Set(['u4']));
  assert.deepEqual(groups[2], ['u4']);
});

test('teams & spawns: distinct spawn positions and team-based hostility', async () => {
  const { generateSpawnPositions, areHostile } = await import('./rules');
  const spawns = generateSpawnPositions(6, 34);
  assert.equal(spawns.length, 6);
  for (let i = 0; i < spawns.length; i++) {
    for (let j = i + 1; j < spawns.length; j++) {
      const dist = Math.hypot(spawns[i].x - spawns[j].x, spawns[i].z - spawns[j].z);
      assert.ok(dist > 20, `Spawn ${i} and ${j} too close: ${dist}`);
    }
  }

  assert.equal(areHostile({ faction: 'slot_1', team: 1 }, { faction: 'slot_2', team: 1 }), false);
  assert.equal(areHostile({ faction: 'slot_1', team: 1 }, { faction: 'slot_2', team: 2 }), true);
  assert.equal(areHostile({ faction: 'slot_1', team: 1 }, { faction: 'neutral' }), false);
});

test('civilizations: each civ has distinct workers, buildable structures, training rosters, and tech upgrades', async () => {
  const {
    canUnitGainXp,
    getCivilizationConfig,
    getBuildableTypesForCiv,
    getTrainableUnitsForBuilding,
    getAvailableTechsForBuilding,
    applyCivilizationAndTechStats,
    computeUnitXpGain,
    dampAngle,
    dampScalar,
  } = await import('./civilizations');

  const med = getCivilizationConfig('medieval');
  const ani = getCivilizationConfig('anime');
  const fan = getCivilizationConfig('fantasy');

  assert.equal(med.workerUnitId, 'villager');
  assert.equal(ani.workerUnitId, 'anime_spirit_harvester');
  assert.equal(fan.workerUnitId, 'fantasy_goblin_sapper');

  assert.ok(getBuildableTypesForCiv('medieval').includes('armory_forge'));
  assert.ok(!getBuildableTypesForCiv('medieval').includes('spirit_shrine'));
  assert.ok(getBuildableTypesForCiv('anime').includes('spirit_shrine'));
  assert.ok(getBuildableTypesForCiv('fantasy').includes('mana_well'));

  // Building training rosters are tailored per civilization
  assert.deepEqual(getTrainableUnitsForBuilding('barracks', 'anime'), ['anime_katana_shinigami', 'anime_saiyan_brawler', 'battering_ram']);
  assert.deepEqual(getTrainableUnitsForBuilding('barracks', 'fantasy'), ['fantasy_paladin', 'fantasy_treant', 'battering_ram']);
  assert.deepEqual(getTrainableUnitsForBuilding('barracks', 'medieval'), ['swordsman', 'knight', 'battering_ram', 'catapult']);

  // Tech research filtering and stat application
  const shrineTechs = getAvailableTechsForBuilding('spirit_shrine', 'anime', [], 1);
  assert.equal(shrineTechs.length, 2);
  const afterOne = getAvailableTechsForBuilding('spirit_shrine', 'anime', ['ani_chakra_flow'], 1);
  assert.equal(afterOne.length, 1);

  const baseStats = {
    maxHp: 100,
    attack: 10,
    defense: 2,
    range: 1.5,
    speed: 4,
    attackRate: 1,
    cost: { food: 50, wood: 0, gold: 20, stone: 0 },
    trainTime: 10,
    gatherSpeed: 0,
    carryCapacity: 0,
  };
  const upgraded = applyCivilizationAndTechStats(baseStats, 'melee', 'anime', ['ani_chakra_flow', 'ani_shunpo']);
  assert.equal(upgraded.attack, 14);
  assert.ok(upgraded.speed > 4.8);

  // XP & Leveling progression (strictly exclusive to anime_saiyan_brawler)
  assert.equal(canUnitGainXp('anime_saiyan_brawler', 'anime'), true);
  assert.equal(canUnitGainXp('anime_katana_shinigami', 'anime'), false);
  assert.equal(canUnitGainXp('anime_ninja_assassin', 'anime'), false);
  assert.equal(canUnitGainXp('swordsman', 'medieval'), false);
  assert.equal(canUnitGainXp('villager', 'medieval'), false);
  assert.equal(canUnitGainXp('fantasy_paladin', 'fantasy'), false);

  const xpRes = computeUnitXpGain(40, 1, 30);
  assert.equal(xpRes.xp, 70);
  assert.equal(xpRes.level, 2);
  assert.equal(xpRes.levelsGained, 1);

  // Shortest-arc damped angle handles wrap-around across PI/-PI without reverse spin
  const nearPi = Math.PI - 0.1;
  const acrossPi = -Math.PI + 0.1;
  const stepped = dampAngle(nearPi, acrossPi, 10, 0.05);
  // Stepping from +3.04 toward -3.04 via +0.2 rad shortest path should stay near PI (abs > 2.9)
  assert.ok(Math.abs(stepped) > 2.9, `Expected shortest-arc wrap around PI, got ${stepped}`);

  const damped = dampScalar(0, 10, 10, 0.1);
  assert.ok(damped > 5 && damped < 10);
});

test('resources & map fairness: maxDistance cap and guaranteed starter resources for 4 spawns across all presets', async () => {
  const { generateMapLayout } = await import('./mapGenerator');
  const { generateSpawnPositions } = await import('./rules');

  // maxDistance cap excludes far nodes
  const farNodes: ResourceNode[] = [
    { id: 'farGold', resourceType: 'gold', x: 40, z: 0, amount: 500, maxAmount: 500 },
  ];
  assert.equal(findClosestResourceNode(0, 0, farNodes, 'gold', 24), null);
  assert.equal(findClosestResourceNode(0, 0, farNodes, 'gold', 45)?.id, 'farGold');

  const spawns = generateSpawnPositions(4, 36).map((sp, i) => ({ id: `slot_${i + 1}`, x: sp.x, z: sp.z }));
  for (const preset of ['river_valley', 'highland_basin', 'twin_lakes'] as const) {
    const layout = generateMapLayout(preset, 'standard', spawns);
    for (const sp of spawns) {
      const hasGold = layout.resourceNodes.some(
        (n) => n.resourceType === 'gold' && Math.hypot(n.x - sp.x, n.z - sp.z) <= 24
      );
      const hasStone = layout.resourceNodes.some(
        (n) => n.resourceType === 'stone' && Math.hypot(n.x - sp.x, n.z - sp.z) <= 24
      );
      const hasWood = layout.resourceNodes.some(
        (n) => n.resourceType === 'wood' && Math.hypot(n.x - sp.x, n.z - sp.z) <= 24
      );
      const hasFood = layout.resourceNodes.some(
        (n) => n.resourceType === 'food' && Math.hypot(n.x - sp.x, n.z - sp.z) <= 24
      );
      assert.ok(hasGold, `${preset} spawn ${sp.id} missing nearby gold`);
      assert.ok(hasStone, `${preset} spawn ${sp.id} missing nearby stone`);
      assert.ok(hasWood, `${preset} spawn ${sp.id} missing nearby wood`);
      assert.ok(hasFood, `${preset} spawn ${sp.id} missing nearby food`);
    }
  }
});

test('hotkeys: worker build, training slots, and tech slots map cleanly without WASD collisions', async () => {
  const {
    BUILDING_HOTKEYS,
    eventCodeToHotkeyLabel,
    findBuildingTypeByHotkey,
    findTrainingUnitByHotkey,
    findTechIdByHotkey,
  } = await import('./hotkeys');
  const { getBuildableTypesForCiv } = await import('./civilizations');

  const wasdReserved = new Set(['W', 'A', 'S', 'D', 'Q', 'F', 'X', 'H', 'B', 'I', 'M', 'P']);
  Object.values(BUILDING_HOTKEYS).forEach((k) => {
    assert.ok(k && !wasdReserved.has(k), `Building hotkey ${k} conflicts with camera/global keys`);
  });

  assert.equal(eventCodeToHotkeyLabel('KeyV'), 'V');
  assert.equal(findBuildingTypeByHotkey('K', getBuildableTypesForCiv('medieval')), 'armory_forge');
  assert.equal(findBuildingTypeByHotkey('K', getBuildableTypesForCiv('anime')), 'spirit_shrine');
  assert.equal(findBuildingTypeByHotkey('K', getBuildableTypesForCiv('fantasy')), 'mana_well');
  assert.equal(findBuildingTypeByHotkey('V', getBuildableTypesForCiv('medieval')), 'barracks');
  assert.equal(findTrainingUnitByHotkey('C', ['swordsman', 'knight', 'catapult']), 'knight');
  assert.equal(findTechIdByHotkey('R', ['tech_a', 'tech_b']), 'tech_a');
  assert.equal(findTechIdByHotkey('T', ['tech_a', 'tech_b']), 'tech_b');
});

test('all-ai spectator: isAllAiMatch and resolveMatchOutcome handle zero-human multi-team AI battles', async () => {
  const { isAllAiMatch, resolveMatchOutcome } = await import('./rules');
  const allAiParticipants = [
    { id: 'ai1', name: 'AI 1', controller: 'ai' as const, team: 1, colorHex: 0, colorCss: '#3b82f6', accentHex: 0 },
    { id: 'ai2', name: 'AI 2', controller: 'ai' as const, team: 2, colorHex: 0, colorCss: '#ef4444', accentHex: 0 },
    { id: 'ai3', name: 'AI 3', controller: 'ai' as const, team: 3, colorHex: 0, colorCss: '#10b981', accentHex: 0 },
  ];
  assert.equal(isAllAiMatch(allAiParticipants), true);

  const mkBldg = (faction: string, team: number, hp = 1000) => ({
    faction,
    team,
    hp,
    buildingType: 'town_center' as const,
  });

  // Still 2 alive teams -> match continues
  const midGame = resolveMatchOutcome(
    allAiParticipants,
    [],
    [mkBldg('ai1', 1, 1000), mkBldg('ai2', 2, 0), mkBldg('ai3', 3, 900)]
  );
  assert.equal(midGame.isOver, false);

  // Only team 3 survives -> victory for team 3
  const endGame = resolveMatchOutcome(
    allAiParticipants,
    [],
    [mkBldg('ai1', 1, 0), mkBldg('ai2', 2, 0), mkBldg('ai3', 3, 900)]
  );
  assert.equal(endGame.isOver, true);
  assert.equal(endGame.winner?.team, 3);
  assert.deepEqual(endGame.winner?.names, ['AI 3']);
});

test('ai-planner & economy: evaluateAiPlan prevents rule starvation and computeAiWorkerAllocation balances deficits', async () => {
  const { evaluateAiPlan, computeAiWorkerAllocation } = await import('./rules');
  const rules: AiRule[] = [
    {
      id: 'atk',
      name: 'Cluster Attack',
      enabled: true,
      conditions: [{ field: 'armyCount', operator: '>=', value: 8 }],
      action: { type: 'cluster_attack', priority: 85 },
    },
    {
      id: 'worker',
      name: 'Train Worker',
      enabled: true,
      conditions: [
        { field: 'food', operator: '>=', value: 50 },
        { field: 'workerCount', operator: '<', value: 12 },
      ],
      action: { type: 'train_unit', targetId: 'villager', priority: 75 },
    },
    {
      id: 'army',
      name: 'Train Swordsman',
      enabled: true,
      conditions: [{ field: 'food', operator: '>=', value: 70 }],
      action: { type: 'train_unit', targetId: 'swordsman', priority: 65 },
    },
    {
      id: 'age',
      name: 'Advance Age',
      enabled: true,
      conditions: [
        { field: 'food', operator: '>=', value: 400 },
        { field: 'gold', operator: '>=', value: 200 },
        { field: 'age', operator: '<', value: 2 },
      ],
      action: { type: 'advance_age', priority: 78 },
    },
    {
      id: 'eco',
      name: 'Gather Military Eco',
      enabled: true,
      conditions: [{ field: 'workerCount', operator: '>=', value: 6 }],
      action: { type: 'gather_priority', targetId: 'military_eco', priority: 70 },
    },
  ];

  const plan = evaluateAiPlan(rules, {
    food: 450,
    wood: 180,
    gold: 230,
    stone: 60,
    armyCount: 9,
    workerCount: 8,
    underAttack: 0,
    enemyProximity: 45,
    gameTime: 95,
    age: 1,
  });

  assert.equal(plan.combatAction?.type, 'cluster_attack');
  assert.equal(plan.buildAction?.type, 'advance_age');
  assert.equal(plan.gatherAction?.targetId, 'military_eco');
  assert.deepEqual(
    plan.trainActions.map((t) => t.targetId),
    ['villager', 'swordsman']
  );

  // Worker allocation prioritizes food when starving
  const starvedAlloc = computeAiWorkerAllocation(
    { food: 30, wood: 250, gold: 180, stone: 100 },
    8,
    'balanced_eco',
    1
  );
  assert.equal(starvedAlloc.food + starvedAlloc.wood + starvedAlloc.gold + starvedAlloc.stone, 8);
  assert.ok(starvedAlloc.food >= 4, `Expected >=4 workers on food when starving, got ${JSON.stringify(starvedAlloc)}`);

  // Overstocked resources should lose allocation weight while every worker remains assigned.
  const stockpiledAlloc = computeAiWorkerAllocation(
    { food: 1800, wood: 1500, gold: 1300, stone: 1000 },
    11,
    'military_eco',
    4
  );
  assert.equal(
    stockpiledAlloc.food + stockpiledAlloc.wood + stockpiledAlloc.gold + stockpiledAlloc.stone,
    11
  );
  assert.ok(stockpiledAlloc.stone <= 2, `Expected low stone allocation with a large stockpile, got ${JSON.stringify(stockpiledAlloc)}`);

  const { selectEconomyRebalancePlan } = await import('./rules');
  const rebalance = selectEconomyRebalancePlan(
    { food: 1, wood: 5, gold: 1, stone: 1 },
    { food: 4, wood: 1, gold: 1, stone: 1 },
    ['food', 'wood']
  );
  assert.deepEqual(rebalance, { from: 'wood', to: 'food' });
  assert.equal(
    selectEconomyRebalancePlan(
      { food: 2, wood: 2, gold: 2, stone: 2 },
      { food: 2, wood: 2, gold: 2, stone: 2 },
      ['food', 'wood', 'gold', 'stone']
    ),
    null
  );
});

test('tactical-combat: 1v1 counter matchups and coordinated cluster focus-fire select optimal targets', async () => {
  const { selectOptimalCombatTarget, selectClusterFocusTarget } = await import('./rules');

  const mkUnit = (
    id: string,
    faction: string,
    team: number,
    category: 'melee' | 'ranged' | 'cavalry' | 'siege' | 'worker',
    x: number,
    z: number,
    hp = 100,
    maxHp = 100,
    range = 1.5,
    speed = 3.8
  ) => ({
    id,
    type: 'unit' as const,
    faction,
    team,
    x,
    z,
    hp,
    maxHp,
    unitDefId: category,
    unitDef: {
      id: category,
      name: category,
      factionPack: 'medieval',
      category,
      description: '',
      stats: {
        maxHp,
        attack: 15,
        defense: 2,
        range,
        speed,
        attackRate: 1,
        cost: { food: 50, wood: 0, gold: 0, stone: 0 },
        trainTime: 10,
        gatherSpeed: 0,
        carryCapacity: 0,
      },
      visual: { color: '#fff', modelType: 'swordsman' as const },
    },
    state: 'idle' as const,
    attackCooldown: 0,
    abilityCooldown: 0,
    velocity: { x: 0, z: 0 },
    kills: 0,
  });

  const mkBldg = (id: string, faction: string, team: number, buildingType: 'farm' | 'tower', x: number, z: number) => ({
    id,
    type: 'building' as const,
    faction,
    team,
    x,
    z,
    hp: 800,
    maxHp: 800,
    buildingType,
    buildingDef: {
      id: buildingType,
      name: buildingType,
      description: '',
      maxHp: 800,
      cost: { food: 0, wood: 100, gold: 0, stone: 0 },
      buildTime: 15,
      trainableUnits: [],
      size: 2.5,
    },
    isConstructed: true,
    buildProgress: 1,
    queue: [],
    queueProgress: 0,
    attackCooldown: 0,
  });

  // 1. Cavalry should flank enemy archer even when enemy swordsman is slightly closer
  const knight = mkUnit('k1', 'ai1', 1, 'cavalry', 0, 0, 210, 210, 1.8, 5.6);
  const enemyMelee = mkUnit('em1', 'ai2', 2, 'melee', 4, 0, 110, 110, 1.5, 3.8);
  const enemyArcher = mkUnit('ea1', 'ai2', 2, 'ranged', 7, 0, 65, 65, 14, 3.4);
  const cavPick = selectOptimalCombatTarget(knight, [enemyMelee, enemyArcher], [], [knight]);
  assert.equal(cavPick?.id, 'ea1');

  // 2. Siege catapult should prioritize enemy defensive Watch Tower over a skirmisher
  const catapult = mkUnit('cat1', 'ai1', 1, 'siege', 0, 0, 160, 160, 18, 2.2);
  const enemyTower = mkBldg('tw1', 'ai2', 2, 'tower', 12, 0);
  const siegePick = selectOptimalCombatTarget(catapult, [enemyMelee], [enemyTower], [catapult]);
  assert.equal(siegePick?.id, 'tw1');

  // 3. Melee defender should attack enemy soldier threatening base instead of a closer Farm
  const swordsman = mkUnit('sw1', 'ai1', 1, 'melee', 0, 0);
  const enemyFarm = mkBldg('fm1', 'ai2', 2, 'farm', 3, 0);
  const meleePick = selectOptimalCombatTarget(swordsman, [enemyMelee], [enemyFarm], [swordsman]);
  assert.equal(meleePick?.id, 'em1');

  // 4. Cluster focus-fire prioritizes wounded high-value enemy archer
  const squad = [
    mkUnit('a1', 'ai1', 1, 'ranged', 0, 0, 65, 65, 14, 3.4),
    mkUnit('a2', 'ai1', 1, 'ranged', 1, 1, 65, 65, 14, 3.4),
    mkUnit('s1', 'ai1', 1, 'melee', 2, 0, 110, 110, 1.5, 3.8),
  ];
  const woundedArcher = mkUnit('eaLow', 'ai2', 2, 'ranged', 8, 1, 20, 65, 14, 3.4);
  const healthyMelee = mkUnit('emFull', 'ai2', 2, 'melee', 7, 0, 110, 110, 1.5, 3.8);
  const clusterTarget = selectClusterFocusTarget(squad, [healthyMelee, woundedArcher], [enemyFarm]);
  assert.equal(clusterTarget?.id, 'eaLow');
});

test('audio-locomotion-buildings: spatial gain, staged construction/damage visuals, and stride phase math', async () => {
  const { computeSpatialAudioGain, computeBuildingVisualState, computeStridePhaseDelta } = await import('./rules');

  // 1. Spatial audio attenuation
  assert.equal(computeSpatialAudioGain(0, 42), 1);
  assert.equal(computeSpatialAudioGain(42, 42), 0);
  assert.equal(computeSpatialAudioGain(65, 42), 0);
  assert.equal(computeSpatialAudioGain(-5, 42), 1);
  const nearGain = computeSpatialAudioGain(10, 42);
  const farGain = computeSpatialAudioGain(30, 42);
  assert.ok(nearGain > farGain && farGain > 0, `Expected monotonic rolloff: near=${nearGain}, far=${farGain}`);

  // 2. Staged building construction & progressive damage states
  const stage1 = computeBuildingVisualState(false, 0.15, 180, 1200);
  assert.equal(stage1.stage, 1);
  assert.equal(stage1.showScaffold, true);
  assert.ok(stage1.tier1Reveal > 0.4 && stage1.tier2Reveal === 0 && stage1.tier3Reveal === 0);
  assert.equal(stage1.isSmoking, false);

  const stage2 = computeBuildingVisualState(false, 0.5, 600, 1200);
  assert.equal(stage2.stage, 2);
  assert.equal(stage2.showScaffold, true);
  assert.ok(stage2.tier2Reveal > 0.5 && stage2.tier3Reveal === 0);

  const stage3 = computeBuildingVisualState(false, 0.85, 1020, 1200);
  assert.equal(stage3.stage, 3);
  assert.equal(stage3.showScaffold, true);
  assert.ok(stage3.tier3Reveal > 0.5);

  const healthyBuilt = computeBuildingVisualState(true, 1, 1200, 1200);
  assert.equal(healthyBuilt.stage, 4);
  assert.equal(healthyBuilt.showScaffold, false);
  assert.equal(healthyBuilt.tier1Reveal, 1);
  assert.equal(healthyBuilt.tier2Reveal, 1);
  assert.equal(healthyBuilt.tier3Reveal, 1);
  assert.equal(healthyBuilt.isSmoking, false);
  assert.equal(healthyBuilt.isBurning, false);
  assert.equal(healthyBuilt.sagTiltRad, 0);

  const damagedSmoking = computeBuildingVisualState(true, 1, 720, 1200); // 60% HP
  assert.equal(damagedSmoking.isSmoking, true);
  assert.equal(damagedSmoking.isBurning, false);
  assert.ok(damagedSmoking.damageSeverity > 0.1);

  const criticalBurning = computeBuildingVisualState(true, 1, 300, 1200); // 25% HP
  assert.equal(criticalBurning.isSmoking, true);
  assert.equal(criticalBurning.isBurning, true);
  assert.ok(criticalBurning.sagTiltRad > 0.01);

  // 3. Distance-locked locomotion phase delta
  assert.equal(computeStridePhaseDelta(0, 1, false), 0);
  assert.equal(computeStridePhaseDelta(-1, 1, false), 0);
  const footStep = computeStridePhaseDelta(0.115, 1, false); // 1/8 of 0.92m full cycle -> PI/4
  assert.ok(Math.abs(footStep - Math.PI / 4) < 0.02, `Expected ~PI/4 rad for 1/8 foot cycle, got ${footStep}`);
  const giantStep = computeStridePhaseDelta(0.115, 1.5, false);
  assert.ok(giantStep < footStep, 'Larger unit scale should take slower angular cadence per meter');
  const mountStep = computeStridePhaseDelta(0.115, 1, true);
  assert.ok(mountStep < footStep, 'Mounted stride covers more ground per gait cycle');
  assert.equal(computeStridePhaseDelta(100, 1, false), 1.15, 'Large teleports/jumps must clamp phase delta');
});

test('collision-tightening: resource hulls and special building radii prevent visual clipping while keeping flush paths', async () => {
  const {
    resolveUnitResourceCollisions,
    getResourceColliderRadius,
    getBuildingCollisionRadius,
    getUnitColliderRadius,
  } = await import('./collision');
  const worker = {
    id: 'w1',
    type: 'unit' as const,
    faction: 'player' as const,
    x: 0.2,
    z: 0.2,
    hp: 65,
    maxHp: 65,
    unitDefId: 'villager',
    unitDef: {
      id: 'villager',
      name: '村民',
      factionPack: 'medieval',
      category: 'worker' as const,
      description: '',
      stats: { maxHp: 65, attack: 4, defense: 0, range: 1, speed: 3.6, attackRate: 1, cost: { food: 50, wood: 0, gold: 0, stone: 0 }, trainTime: 8, gatherSpeed: 5, carryCapacity: 15 },
      visual: { color: '#fff', modelType: 'villager' as const },
    },
    state: 'gathering' as const,
    attackCooldown: 0,
    abilityCooldown: 0,
    velocity: { x: 0, z: 0 },
    kills: 0,
  };

  const stoneNode = { id: 'st1', resourceType: 'stone' as const, x: 0, z: 0, amount: 800, maxAmount: 800 };
  resolveUnitResourceCollisions([worker], [stoneNode]);
  const stoneDist = Math.hypot(worker.x, worker.z);
  const minClear = getResourceColliderRadius(stoneNode.resourceType, undefined) + getUnitColliderRadius('worker') * 0.45;
  assert.ok(stoneDist >= minClear - 0.01, `Worker pushed outside stone quarry boundary (${stoneDist} >= ${minClear})`);

  const berryNode = { id: 'br1', resourceType: 'food' as const, subtype: 'berry' as const, x: 10, z: 0, amount: 400, maxAmount: 400 };
  assert.ok(getResourceColliderRadius(berryNode.resourceType, berryNode.subtype) >= 1.0, 'Berry bush keeps physical radius so units never stand inside bush foliage');

  const barracks = {
    id: 'bk1',
    type: 'building' as const,
    faction: 'player' as const,
    x: 0,
    z: 0,
    hp: 1400,
    maxHp: 1400,
    buildingType: 'barracks' as const,
    buildingDef: { id: 'barracks' as const, name: 'Barracks', description: '', maxHp: 1400, cost: { food: 0, wood: 150, gold: 0, stone: 0 }, buildTime: 20, trainableUnits: [], size: 3.5 },
    isConstructed: true,
    buildProgress: 1,
    queue: [],
    queueProgress: 0,
    attackCooldown: 0,
  };
  assert.ok(getBuildingCollisionRadius(barracks) >= 2.65 && getBuildingCollisionRadius(barracks) < 3.5);
});

test('siege-and-garrison: anti-building armor blocks early soldiers while siege engines ignore armor, and garrison shelters & empowers buildings', async () => {
  const {
    getEffectiveBuildingArmor,
    calculateBuildingDamage,
    getUnitVsUnitDamage,
    getBuildingMaxGarrison,
    computeGarrisonDefenseProfile,
  } = await import('./rules');
  const { DEFAULT_BUILDINGS, MEDIEVAL_UNITS } = await import('./mods');
  const { applyCivilizationAndTechStats } = await import('./civilizations');

  const byId = (id: string) => {
    const u = MEDIEVAL_UNITS.find((def) => def.id === id);
    if (!u) throw new Error(`Missing unit def ${id}`);
    return u;
  };
  const villagerDef = byId('villager');
  const archerDef = byId('longbowman');
  const swordsmanDef = byId('swordsman');
  const ramDef = byId('battering_ram');
  const cannonDef = byId('bombard_cannon');

  const tc = {
    id: 'tc1',
    type: 'building' as const,
    faction: 'enemy' as const,
    team: 2,
    x: 20,
    z: 20,
    hp: 3000,
    maxHp: 3000,
    buildingType: 'town_center' as const,
    buildingDef: DEFAULT_BUILDINGS.town_center,
    isConstructed: true,
    buildProgress: 1,
    queue: [],
    queueProgress: 0,
    attackCooldown: 0,
    garrisonedUnitIds: [] as string[],
  };
  const armory = { ...tc, id: 'arm1', buildingType: 'armory_forge' as const, buildingDef: DEFAULT_BUILDINGS.armory_forge };
  const tower = { ...tc, id: 'tw1', buildingType: 'tower' as const, buildingDef: DEFAULT_BUILDINGS.tower };

  // 1. Garrison capacities: Special buildings hold more (14) than TC (10) and Watch Tower (5)
  assert.equal(getBuildingMaxGarrison(armory), 14);
  assert.equal(getBuildingMaxGarrison(tc), 10);
  assert.equal(getBuildingMaxGarrison(tower), 5);

  // 2. Town Center starts unmanned with 0 defensive shots, then fires scaled volleys when garrisoned
  const unmannedTcDef = computeGarrisonDefenseProfile(tc, [], []);
  assert.equal(unmannedTcDef.volleyCount, 0);
  assert.equal(unmannedTcDef.damagePerBolt, 0);

  const mkUnitEnt = (id: string, def: typeof villagerDef, garrisonedIn?: string) => ({
    id,
    type: 'unit' as const,
    faction: 'enemy' as const,
    team: 2,
    x: 20,
    z: 20,
    hp: def.stats.maxHp,
    maxHp: def.stats.maxHp,
    unitDefId: def.id,
    unitDef: def,
    state: 'idle' as const,
    attackCooldown: 0,
    abilityCooldown: 0,
    velocity: { x: 0, z: 0 },
    kills: 0,
    garrisonedInBuildingId: garrisonedIn,
  });

  const defenders = [
    mkUnitEnt('d1', archerDef, 'tc1'),
    mkUnitEnt('d2', archerDef, 'tc1'),
    mkUnitEnt('d3', villagerDef, 'tc1'),
    mkUnitEnt('d4', villagerDef, 'tc1'),
  ];
  tc.garrisonedUnitIds = defenders.map((d) => d.id);
  const mannedTcDef = computeGarrisonDefenseProfile(tc, defenders, ['shared_arrow_slits', 'shared_murder_holes']);
  assert.ok(mannedTcDef.volleyCount >= 2 && mannedTcDef.damagePerBolt >= 15, 'Manned Town Center gains multi-arrow volley fire');

  // 3. Garrisoned units must NOT be targetable by enemy units
  assert.equal(findClosestEnemy(18, 18, 'player', defenders), null);

  // 4. Separate anti-building attack & armor balance:
  const tcAge3Armor = getEffectiveBuildingArmor(tc, 3, ['shared_masonry']);
  assert.ok(tcAge3Armor >= 12);
  const swordsmanUnit = mkUnitEnt('sw1', swordsmanDef);
  const swordVsTcDmg = calculateBuildingDamage(swordsmanUnit, tc, 3, ['shared_masonry']);
  assert.ok(swordVsTcDmg <= 3, `Early soldier torch damage (${swordVsTcDmg}) should be strongly mitigated by Masonry TC`);

  // Battering Ram ignores building armor + has high rangedDefense vs arrows
  const ramUnit = mkUnitEnt('ram1', ramDef);
  const ramVsTcDmg = calculateBuildingDamage(ramUnit, tc, 3, ['shared_masonry']);
  assert.ok(ramVsTcDmg >= 90, `Battering ram (${ramVsTcDmg}) should crush building armor`);
  const ramUpgradedStats = applyCivilizationAndTechStats(ramDef.stats, 'siege', 'medieval', ['shared_siege_engineers']);
  assert.ok(ramUpgradedStats.buildingAttack! > ramDef.stats.buildingAttack!);

  const arrowVsRam = getUnitVsUnitDamage(archerDef.stats.attack, ramUnit, true);
  assert.ok(arrowVsRam <= 2, `Battering ram arrow resistance should blunt archers (${arrowVsRam})`);

  const cannonUnit = mkUnitEnt('can1', cannonDef);
  const cannonVsTcDmg = calculateBuildingDamage(cannonUnit, tc, 3, ['shared_masonry']);
  assert.ok(cannonVsTcDmg >= 200, `Imperial bombard cannon (${cannonVsTcDmg}) should devastate fortified structures`);
});






test('mods: faction-specific custom technologies are listed and apply to units', async () => {
  const {
    getAvailableTechsForBuilding,
    getAllTechsForBuilding,
    findTechDef,
    applyCivilizationAndTechStats,
  } = await import('./civilizations');

  const customTech: TechDefinition = {
    id: 'custom_test_gathering',
    civId: 'anime',
    buildingType: 'barracks',
    name: '靈脈物流術',
    icon: '✨',
    description: '改善村民採集效率。',
    effectLabel: '採集速度 +20%',
    cost: { food: 100, wood: 50, gold: 25, stone: 0 },
    researchTime: 12,
    requiredAge: 3,
    targetCategories: ['worker'],
    effect: { gatherMultiplier: 1.2 },
  };

  assert.equal(
    getAvailableTechsForBuilding('barracks', 'anime', [], 2, [customTech]).some((tech) => tech.id === customTech.id),
    false
  );
  assert.equal(
    getAvailableTechsForBuilding('barracks', 'anime', [], 3, [customTech]).some((tech) => tech.id === customTech.id),
    true
  );
  assert.equal(getAllTechsForBuilding('barracks', 'anime', [customTech]).some((tech) => tech.id === customTech.id), true);
  assert.equal(findTechDef(customTech.id, [customTech])?.name, customTech.name);

  const baseStats: UnitStats = {
    maxHp: 50,
    attack: 4,
    defense: 1,
    range: 1,
    speed: 3,
    attackRate: 1,
    cost: { food: 50, wood: 0, gold: 0, stone: 0 },
    trainTime: 10,
    gatherSpeed: 2,
    carryCapacity: 10,
  };
  const boosted = applyCivilizationAndTechStats(baseStats, 'worker', 'anime', [customTech.id], [customTech]);
  assert.ok(boosted.gatherSpeed >= 2.63, `Expected custom technology to increase gather speed, got ${boosted.gatherSpeed}`);
});



test('mods: deep validation accepts shipped packs and normalizes legacy metadata', () => {
  const shipped = validateAndNormalizeGameMods(INITIAL_MODS);
  assert.deepEqual(shipped.errors, []);
  assert.equal(shipped.mods?.length, INITIAL_MODS.length);
  assert.equal(shipped.mods?.[0].civilizationId, 'medieval');

  const legacy = JSON.parse(JSON.stringify(INITIAL_MODS[0])) as Record<string, unknown>;
  delete legacy.civilizationId;
  delete legacy.buildingOverrides;
  delete legacy.techDefinitions;
  const normalized = validateAndNormalizeGameMods([legacy]);
  assert.deepEqual(normalized.errors, []);
  assert.equal(normalized.mods?.[0].civilizationId, 'medieval');
  assert.deepEqual(normalized.mods?.[0].buildingOverrides, {});
  assert.deepEqual(normalized.mods?.[0].techDefinitions, []);
});

test('mods: deep validation rejects extreme abilities, unsafe tech effects and duplicate IDs', () => {
  const safeBase = JSON.parse(JSON.stringify(INITIAL_MODS[0])) as GameMod;
  safeBase.id = 'custom_validation_pack';
  safeBase.name = 'Validation Pack';
  safeBase.unitDefinitions = [{
    id: 'custom_validation_hero',
    name: 'Validation Hero',
    factionPack: 'custom',
    isHero: true,
    category: 'melee',
    description: 'A test-only unit.',
    stats: {
      maxHp: 100,
      attack: 10,
      defense: 2,
      range: 1.5,
      speed: 4,
      attackRate: 1,
      cost: { food: 50, wood: 0, gold: 25, stone: 0 },
      trainTime: 10,
      gatherSpeed: 0,
      carryCapacity: 0,
    },
    visual: { color: '#ffffff', modelType: 'swordsman' },
    specialAbility: {
      name: 'Burst',
      type: 'ki_burst',
      cooldown: 10,
      potency: 99999,
      description: 'Unsafe potency should be rejected.',
    },
  }];
  assert.ok(validateGameMods([safeBase]).some((error) => error.includes('威力')));

  const unsafeTechPack = JSON.parse(JSON.stringify(safeBase)) as GameMod;
  unsafeTechPack.unitDefinitions[0].specialAbility!.potency = 50;
  unsafeTechPack.techDefinitions = [{
    id: 'custom_validation_tech',
    civId: 'shared',
    buildingType: 'town_center',
    name: 'Overclock',
    icon: '⚡',
    description: 'Test only',
    effectLabel: 'Gather rate multiplier',
    cost: { food: 100, wood: 0, gold: 0, stone: 0 },
    researchTime: 10,
    targetCategories: ['worker'],
    effect: { gatherMultiplier: 99 },
  }];
  assert.ok(validateGameMods([unsafeTechPack]).some((error) => error.includes('gatherMultiplier')));

  const duplicate = JSON.parse(JSON.stringify(unsafeTechPack)) as GameMod;
  duplicate.id = 'another_custom_pack';
  duplicate.unitDefinitions[0].id = unsafeTechPack.unitDefinitions[0].id;
  assert.ok(validateGameMods([unsafeTechPack, duplicate]).some((error) => error.includes('單位 ID 重複')));
});

test('economy: rebalance planner ignores resources without active nodes', async () => {
  const { selectEconomyRebalancePlan } = await import('./rules');
  assert.equal(
    selectEconomyRebalancePlan(
      { food: 1, wood: 6, gold: 1, stone: 1 },
      { food: 5, wood: 1, gold: 1, stone: 1 },
      ['wood']
    ),
    null
  );
  assert.deepEqual(
    selectEconomyRebalancePlan(
      { food: 1, wood: 6, gold: 1, stone: 1 },
      { food: 5, wood: 1, gold: 1, stone: 1 },
      ['food', 'wood']
    ),
    { from: 'wood', to: 'food' }
  );
});
